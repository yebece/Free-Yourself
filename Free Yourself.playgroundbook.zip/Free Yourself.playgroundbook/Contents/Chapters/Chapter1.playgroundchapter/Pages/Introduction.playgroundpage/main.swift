//#-hidden-code
import SwiftUI
import PlaygroundSupport


// Made by Yusuf Berk Çekiç for WWDC21

struct BegginingView: View {
    
    
    @State public var isBeggining = true
    @State public var opacity_0 = 0.0
    @State public var opacity_1 = 0.0
    @State public var opacity_2 = 0.0
    @State public var opacity_3 = 0.0
    @State public var x_0 = 0
    @State public var x_1 = 1000
    @State public var x_2 = 1000
    @State public var x_3 = 1000
    @State public var zIndex_0 = 20
    @State public var zIndex_1 = 19
    @State public var zIndex_2 = 18
    @State public var zIndex_3 = 17
    
    var body: some View {
        
        ZStack {
            Image(uiImage: #imageLiteral(resourceName: "background.png"))
                .resizable()
                .aspectRatio(contentMode: .fill)
                .zIndex(-500)
            
            // Fourth Slide
            VStack{
                Image(uiImage: #imageLiteral(resourceName: "FreeYourselfLogo.png"))
                    .resizable()
                    .scaledToFit()
                    .frame(width: 130.0,height:81.0)
                Text(IntroductionData[3]).font(.system(size: 36.0, weight: .medium, design: .rounded)).foregroundColor(.black).frame(width: 940).multilineTextAlignment(.center)
            }.opacity(opacity_3)
            .offset(x: CGFloat(x_3))
            .zIndex(Double(zIndex_3))
            
            // Third Slide
            VStack(alignment: .leading){
                HStack(){
                    Image(uiImage: #imageLiteral(resourceName: "FreeYourselfLogo.png"))
                        .resizable()
                        .scaledToFit()
                        .frame(width: 130.0,height:81.0)
                    Text("Types of addictions").font(.system(size: 72.0, weight: .semibold, design: .rounded)).foregroundColor(.black)
                }
                VStack{
                    Text(IntroductionData[2]).font(.system(size: 48.0, weight: .medium, design: .rounded)).foregroundColor(.black).frame(width: 915)
                    HStack(spacing: 100){
                        VStack{
                            Image(uiImage: #imageLiteral(resourceName: "alcohol.png"))
                                .resizable()
                                .scaledToFit()
                                .frame(width: 200,height:200)
                            Text("Alcohol Addiction").font(.system(size: 28.0, weight: .medium, design: .rounded)).foregroundColor(.black)
                        }
                        VStack{
                            Image(uiImage: #imageLiteral(resourceName: "tobacco.png"))
                                .resizable()
                                .scaledToFit()
                                .frame(width: 200,height:200)
                            Text("Tobacco Addiction").font(.system(size: 28.0, weight: .medium, design: .rounded)).foregroundColor(.black)
                        }
                        VStack{
                            Image(uiImage: #imageLiteral(resourceName: "iphone.png"))
                                .resizable()
                                .scaledToFit()
                                .frame(width: 200,height:200)
                            Text("Internet Addiction").font(.system(size: 28.0, weight: .medium, design: .rounded)).foregroundColor(.black)
                        }
                    }
                }
                Button(action: {
                    withAnimation(Animation.easeIn(duration: 1)){
                        self.x_2 = -1000
                        self.opacity_2 = 0.0
                        self.x_3 = 0
                        self.opacity_3 = 1.0
                        self.zIndex_3 = 22
                        switchPage()
                    }
                }, label:{
                    HStack{
                        Text("Next").font(.system(size: 30.0, weight: .semibold, design: .rounded)).frame(width: 100, height: 30, alignment: .leading)
                        Text("􀆊").font(.system(size: 30.0, weight: .semibold, design: .rounded)).frame(width: 100, height: 30, alignment: .trailing)
                    }
                }).foregroundColor(.black).padding(.leading, 7)
                
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 34)
                        .stroke(Color.black, lineWidth: 5)
                ).offset(y: 20)
                
            }.opacity(opacity_2)
            .offset(x: CGFloat(x_2))
            .zIndex(Double(zIndex_2))
            
            
            // Second Slide
            VStack(alignment: .leading){
                HStack(){
                    Image(uiImage: #imageLiteral(resourceName: "FreeYourselfLogo.png"))
                        .resizable()
                        .scaledToFit()
                        .frame(width: 130.0,height:81.0)
                    Text("What is addiction?").font(.system(size: 72.0, weight: .semibold, design: .rounded)).foregroundColor(.black)
                }
                Text(IntroductionData[0]).font(.system(size: 48.0, weight: .medium, design: .rounded)).foregroundColor(.black).frame(width: 780, alignment: .leading)
                
                Text(IntroductionData[1]).font(.system(size: 28.0, weight: .medium, design: .rounded)).foregroundColor(.init(#colorLiteral(red: 0.5741509199142456, green: 0.5741509199142456, blue: 0.5741509199142456, alpha: 1.0)))
                Button(action: {
                    withAnimation(Animation.easeIn(duration: 1)){
                        self.x_1 = -1000
                        self.opacity_1 = 0.0
                        self.x_2 = 0
                        self.opacity_2 = 1.0
                        self.zIndex_2 = 22
                    }
                }, label:{
                    HStack{
                        Text("Next").font(.system(size: 30.0, weight: .semibold, design: .rounded)).frame(width: 100, height: 30, alignment: .leading)
                        Text("􀆊").font(.system(size: 30.0, weight: .semibold, design: .rounded)).frame(width: 100, height: 30, alignment: .trailing)
                    }
                }).foregroundColor(.black).padding(.leading, 7)
                
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 34)
                        .stroke(Color.black, lineWidth: 5)
                ).offset(y: 10)
                
            }.opacity(opacity_1)
            .offset(x: CGFloat(x_1))
            .zIndex(Double(zIndex_1))
            
            // First Slide
            VStack(){
                Image(uiImage: #imageLiteral(resourceName: "FreeYourselfLogo.png"))
                Text("an WWDC21 project").offset(y: -35).font(.system(size: 28.0, weight: .semibold, design: .rounded))
                    .foregroundColor(.black)
                Button(action: {
                    withAnimation(Animation.easeIn(duration: 1)){
                        self.x_0 = -1000
                        self.opacity_0 = 0.0
                        self.x_1 = 0
                        self.opacity_1 = 1.0
                        self.zIndex_1 = 21
                    }
                }, label:{
                    Text("Start").font(.system(size: 30.0, weight: .semibold, design: .rounded))
                        .frame(width: 200, height: 30)
                }).foregroundColor(.black)
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 34)
                        .stroke(Color.black, lineWidth: 5)
                ).offset(y: 40)
            }.offset(x: CGFloat(x_0))
            .opacity(opacity_0)
            .zIndex(Double(zIndex_0))
            .onAppear {
                withAnimation(Animation.easeIn(duration: 2).delay(0.5)){
                    if self.isBeggining == true{
                        self.opacity_0 = 1.0
                        self.isBeggining.toggle()
                    }else{
                        
                    }
                    
                }
                
            }
        }
    }
}

func switchPage(){
    var switchpage = NSLocalizedString("Switch to the \"The Game\" page\n\n[**Next Page**](@next)", comment:"Success message")
    PlaygroundPage.current.assessmentStatus = .pass(message: switchpage)
}

PlaygroundPage.current.setLiveView(BegginingView())
PlaygroundPage.current.wantsFullScreenLiveView = true



//#-end-hidden-code
/*:
 
  !["Banner"](banner.png)
 
 # Welcome to the Free Yourself

Free Yourself's main purpose is teaching people about addictions and showing how anyone get addicted.

 
▪️ First Introduction Page is a presentation show that including information about addictions.

▪️ The Second Game Page is a mini life simulator game about addictions.

 
 ## Now, let's get started! ✌️
 
 */
