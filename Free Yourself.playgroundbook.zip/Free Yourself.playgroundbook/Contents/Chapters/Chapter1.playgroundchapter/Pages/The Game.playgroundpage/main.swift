//#-hidden-code
import SpriteKit
import SwiftUI
import PlaygroundSupport

@available(macCatalystApplicationExtension 14.0, *)
struct ContentView: View {
    var scene: SKScene {
        let scene = Scene()
        scene.size = CGSize(width: 1024, height: 640)
        scene.scaleMode = .fill
        return scene
    }
    
    var body: some View {
        ZStack {
            Image(uiImage: #imageLiteral(resourceName: "background_dark.png"))
                .resizable()
                .aspectRatio(contentMode: .fill)
                .zIndex(-500)
            SpriteView(scene: scene)
                .frame(width: 1024, height: 640)
                .edgesIgnoringSafeArea(.all)
                .cornerRadius(15)
        }
        
    }
}

if #available(macCatalystApplicationExtension 14.0, *) {
    PlaygroundPage.current.setLiveView(ContentView())
} else {
    // Fallback on earlier versions
}
PlaygroundPage.current.wantsFullScreenLiveView = true
//#-end-hidden-code
/*:
 
 !["Banner"](banner_game.png)
 
 # What's this game about?

This Game is about showing how people get addicted by "little" things. Your decisions change can your addiction level, you can see addiction level at the top left of the screen.

 ---
 
 ## Controls

▪️ Tap 👆 to move.

 
▪️ Tap to the 💬's to continue the game.
 
---
 
 PS: All graphics are designed by me.
 */
