import SpriteKit

public class ButtonActions: SKScene {
    
    public func bubble_0_action() {
    bubble_0.alpha = 1
        // This action fades the screen
    var fades = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
    blackOut.run(fades)
    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
        bubble_0.isHidden = true
        bubble_0_title.isHidden = true
        phone_side.isHidden = true
        addiction += 10.0
        GeneralFuncs().addictionChange()
        // This action shows the scene again
        var deFade = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
        blackOut.run(deFade)
    }             
}
    
    public func bubble_1_action() {
    bubble_1.alpha = 1
        // This action fades the screen
    var fades = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
    blackOut.run(fades)
    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
        bubble_0.isHidden = true
        bubble_0_title.isHidden = true
        bubble_1.isHidden = true
        bubble_1_title.isHidden = true
        phone_side.isHidden = true
        char_clothes = "char_working_"
        let changeClothes = SKTexture(imageNamed: char_clothes + "left.png")
        player.texture = changeClothes
        GeneralFuncs().addictionChange()
        bubble_2.isHidden = false
        bubble_2_title.isHidden = false
        // This action shows the scene again
        var deFade = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
        blackOut.run(deFade)
    }                
}

    public func bubble_0_1_action() {
    bubble_0_1.alpha = 1
        // This action fades the screen
    var fades = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
    blackOut.run(fades)
    DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
        player.isHidden = true
        bubble_0_1.isHidden = true
        bubble_0_1_title.isHidden = true
        
        chair.size = CGSize(width: 141, height: 247)
        chair.position = CGPoint(x: 400, y: 246.5)
        let chairWorkin = SKTexture(imageNamed: "workin.png")
        chair.texture = chairWorkin
        // This action shows the scene again
        var deFade = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
        blackOut.run(deFade)
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            phone.isHidden = false
            phone_button0.isHidden = false
            phone_button0_title.isHidden = false
            phone_button1.isHidden = false
            phone_button1_title.isHidden = false
            let notificationSound = SKAction.playSoundFileNamed("notification.mp3", waitForCompletion: false)
            phone.run(notificationSound)
        }
    }                
}
    
    public func phone_button0_action(){
    // This action fades the screen
        var fades = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
        blackOut.run(fades)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
            player.isHidden = false
            phone.isHidden = true
            phone_button0.isHidden = true
            phone_button0_title.isHidden = true
            phone_button1.isHidden = true
            phone_button1_title.isHidden = true
            chair.size = CGSize(width: 88, height: 184)
            chair.position = CGPoint(x: 400, y: 215)
            player.position.x = 505
            let playerRight = SKTexture(imageNamed: char_clothes + "right.png")
            player.texture = playerRight
            let chairNormal = SKTexture(imageNamed: "chair.png")
            chair.texture = chairNormal
            if addiction < 30 {
                addiction += 15
            }else if addiction > 30{
                addiction += 25
            }
            GeneralFuncs().addictionChange()
            bubble_1_1.isHidden = false
            bubble_1_1_title.isHidden = false
    // This action shows the scene again
            var deFade = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
            blackOut.run(deFade)
        }                
    }

    public func phone_button1_action() {
        // This action fades the screen
        var fades = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
        blackOut.run(fades)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
            player.isHidden = false
            phone.isHidden = true
            phone_button0.isHidden = true
            phone_button0_title.isHidden = true
            phone_button1.isHidden = true
            phone_button1_title.isHidden = true
            chair.size = CGSize(width: 88, height: 184)
            chair.position = CGPoint(x: 400, y: 215)
            player.position.x = 505
            let playerRight = SKTexture(imageNamed: char_clothes + "right.png")
            player.texture = playerRight
            let chairNormal = SKTexture(imageNamed: "chair.png")
            chair.texture = chairNormal
            if addiction > 30{
                addiction -= 7
            }
            GeneralFuncs().addictionChange()
            bubble_1_1.isHidden = false
            bubble_1_1_title.isHidden = false
            // This action shows the scene again
            var deFade = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
            blackOut.run(deFade)
        }                
    }

    public func bubble_0_2_action() {
        // This action fades the screen
        var fades = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
        blackOut.run(fades)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
            //
            bubble_0_2.isHidden = true
            bubble_0_2_title.isHidden = true
            addiction += 30
            GeneralFuncs().addictionChange()
            bubble_1_2_title.text = """
Back to the work.
"""
            bubble_1_2_title.position = CGPoint(x: bubble_1_2.position.x + 5, y: bubble_1_2.position.y - 10)
            // This action shows the scene again
            var deFade = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
            blackOut.run(deFade)
        }                
    }
    
    public func bubble_1_5_action() {
        if drinkingCount == 0 {
            addiction += 5
            drinkingCount += 1
            bubble_1_5_title.text = """
                \(GameData[15])
                """
            GeneralFuncs().addictionChange()
        } else if drinkingCount == 1 {
            addiction += 10
            drinkingCount += 1
            bubble_1_5_title.text = """
                \(GameData[15])
                """
            GeneralFuncs().addictionChange()
        } else if drinkingCount == 2 {
            addiction += 20
            drinkingCount += 1
            bubble_0_5_title.text = """
                \(GameData[13])
                """
            bubble_0_5_title.position = CGPoint(x: bubble_0_5.position.x + 5, y: bubble_0_5.position.y - 25)
            bubble_1_5.isHidden = true
            bubble_1_5_title.isHidden = true
            GeneralFuncs().addictionChange()
        }

        
    }

}

