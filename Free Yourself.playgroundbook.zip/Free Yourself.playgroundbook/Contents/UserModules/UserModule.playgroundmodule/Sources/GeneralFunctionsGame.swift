import SpriteKit
import SwiftUI
import PlaygroundSupport
    
public class GeneralFuncs : SKScene {
    public func addictionChange(){
        // This functions resets the addiction level bar
        if addiction > 99 {
            addiction = 100.0
        }
        var progressAddiction = addiction * 2.125
        var progressX = 13 + progressAddiction / 2
        progress.size.width = CGFloat(progressAddiction)
        progress.position.x = CGFloat(progressX)
        if addiction < 33.0 {
            let great = SKTexture(imageNamed: "gradientFine.png")
            progress.texture = great
        } else if addiction < 66.0 && addiction > 33.0 {
            let hmm = SKTexture(imageNamed: "gradientHmm.png")
            progress.texture = hmm
        } else if addiction > 66.0 {
            let bad = SKTexture(imageNamed: "gradientBad.png")
            progress.texture = bad
        }
    }
    
    public func endingPage(){ 
        EndingTitle2.text = "Addiction level is " + String(Int(addiction)) + "/100" 
        logo.isHidden = false
        EndingTitle1.isHidden  = false
        EndingTitle2.isHidden = false
        EndingTitle3.isHidden = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            var fades = SKAction.fadeAlpha(to: 1.0, duration: 2.0)
            logo.run(fades)
            EndingTitle1.run(fades)
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                var fades = SKAction.fadeAlpha(to: 1.0, duration: 2.0)
                EndingTitle2.run(fades)
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    var fades = SKAction.fadeAlpha(to: 1.0, duration: 2.0)
                    EndingTitle3.run(fades)
                    var finish = NSLocalizedString("Congrats! You finished the game.", comment:"")
                    PlaygroundPage.current.assessmentStatus = .pass(message: finish)
                }      
            }      
        }            

        
    }
}
    

