import SpriteKit
import SwiftUI

// Data from JSON
public var IntroductionData = TextProvider().getData(dataName: "IntroductionTitles")
public var GameData = TextProvider().getData(dataName: "GameTitles")
public var EndingData = TextProvider().getData(dataName: "EndingPage")

// Main Objects at Game Page
public var background = SKSpriteNode(imageNamed: "stage1.png")
public var blackOut = SKShapeNode(rectOf: CGSize(width: 1280, height: 720))
public var player = SKSpriteNode(imageNamed: char_clothes + "right.png")
public var player_workin = SKSpriteNode(imageNamed: "workin.png")
public var chair = SKSpriteNode(imageNamed: "chair.png")
public var phone_side = SKSpriteNode(imageNamed: "phoneSide.png")
public var phone = SKSpriteNode(imageNamed: "iphone_game.png")
public var phoneInv = SKSpriteNode(imageNamed: "iphone_invitation.png")
public var progress_bar = SKSpriteNode(imageNamed: "progress_bar.png")
public var progress = SKSpriteNode(imageNamed: "gradientFine.png")
public var balconyGuy = SKSpriteNode(imageNamed: "guyAtBalcony.png")

// Text Bubbles and Buttons at Game Page
// stage 0
public var bubble_0 = SKSpriteNode(imageNamed: "bubble.png")
public var bubble_0_title = SKLabelNode(fontNamed: "SF Pro Medium")
public var bubble_1 = SKSpriteNode(imageNamed: "bubbleLeft.png")
public var bubble_1_title = SKLabelNode(fontNamed: "SF Pro Medium")
public var bubble_2 = SKSpriteNode(imageNamed: "bubble.png")
public var bubble_2_title = SKLabelNode(fontNamed: "SF Pro Medium")
// stage 1
public var bubble_0_1 = SKSpriteNode(imageNamed: "bubble.png")
public var bubble_0_1_title = SKLabelNode(fontNamed: "SF Pro Medium")
public var phone_button0 = SKSpriteNode(imageNamed: "button.png")
public var phone_button0_title = SKLabelNode(fontNamed: "Menlo Bold")
public var phone_button1 = SKSpriteNode(imageNamed: "button.png")
public var phone_button1_title = SKLabelNode(fontNamed: "Menlo Bold")
public var bubble_1_1 = SKSpriteNode(imageNamed: "bubbleLeft.png")
public var bubble_1_1_title = SKLabelNode(fontNamed: "SF Pro Medium")
// stage 2
public var bubble_0_2 = SKSpriteNode(imageNamed: "bubble.png")
public var bubble_0_2_title = SKLabelNode(fontNamed: "SF Pro Medium")
public var bubble_1_2 = SKSpriteNode(imageNamed: "bubbleRight.png")
public var bubble_1_2_title = SKLabelNode(fontNamed: "SF Pro Medium")
// stage 3
public var bubble_0_3 = SKSpriteNode(imageNamed: "bubbleRight.png")
public var bubble_0_3_title = SKLabelNode(fontNamed: "SF Pro Medium")
// stage 4
public var phone_button0_3 = SKSpriteNode(imageNamed: "button.png")
public var phone_button0_3_title = SKLabelNode(fontNamed: "Menlo Bold")
public var phone_button1_3 = SKSpriteNode(imageNamed: "button.png")
public var phone_button1_3_title = SKLabelNode(fontNamed: "Menlo Bold")
// stage 5
public var bubble_0_5 = SKSpriteNode(imageNamed: "bubbleRight.png")
public var bubble_0_5_title = SKLabelNode(fontNamed: "SF Pro Medium")
public var bubble_1_5 = SKSpriteNode(imageNamed: "bubble.png")
public var bubble_1_5_title = SKLabelNode(fontNamed: "SF Pro Medium")
// stage 6
public var bubble_0_6 = SKSpriteNode(imageNamed: "bubble.png")
public var bubble_0_6_title = SKLabelNode(fontNamed: "SF Pro Medium")

// Sounds at Game Page
public var notification = SKAction.playSoundFileNamed("notification.mp3", waitForCompletion: false)

// Ending Page
public var logo = SKSpriteNode(imageNamed: "FreeYourselfLogo.png") 
public var EndingTitle1 = SKLabelNode(fontNamed: "SF Pro Rounded Medium")
public var EndingTitle2 = SKLabelNode(fontNamed: "SF Pro Rounded Regular")
public var EndingTitle3 = SKLabelNode(fontNamed: "SF Pro Rounded Medium")

// Other Variables at Game Page
public var addiction = 23.0
public var stage_number = 0
public var progressAddiction = addiction * 2.125
public var progressX = 13 + progressAddiction / 2
public var char_clothes = "char_"
public var drinkingCount  = 0





