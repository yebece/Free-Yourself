import SpriteKit

public class Scene: SKScene {
        public override func didMove(to view: SKView) {
        background.zPosition = -1
        background.position = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
        addChild(background)
        
        blackOut.fillColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        blackOut.alpha = 0
        blackOut.zPosition = 1000
        blackOut.position = CGPoint(x: frame.size.width / 2, y: frame.size.height / 2)
            addChild(blackOut)
        
        player.size = CGSize(width: 100, height: 165)
        player.position = CGPoint(x: 120, y: 205)
        player.zPosition = 500
        addChild(player)
            
            balconyGuy.size = CGSize(width: 179, height: 237)
            balconyGuy.position = CGPoint(x: 530, y: 241)
            balconyGuy.zPosition = 500
            balconyGuy.isHidden = true
            addChild(balconyGuy)
        
        chair.size = CGSize(width: 88, height: 184)
        chair.position = CGPoint(x: 400, y: 215)
        chair.zPosition = 501
        chair.isHidden = true
        addChild(chair)
        
        phone.size = CGSize(width: 400, height: 720)
        phone.position = CGPoint(x: 803, y: 272)
        phone.zPosition = 501
        phone.isHidden = true
        addChild(phone)
            
            phoneInv.size = CGSize(width: 400, height: 720)
            phoneInv.position = CGPoint(x: 803, y: 272)
            phoneInv.zPosition = 501
            phoneInv.isHidden = true
            addChild(phoneInv)
        
        progress_bar.size = CGSize(width: 304.5, height: 156.5)
        progress_bar.position = CGPoint(x: 120, y: 555)
        progress_bar.zPosition = 501
        addChild(progress_bar)
        
        progress.size = CGSize(width: progressAddiction, height: 39.5)
        progress.position = CGPoint(x: progressX, y: 593)
        progress.zPosition = 502
        GeneralFuncs().addictionChange()
        addChild(progress)
        
        phone_side.size = CGSize(width: 75, height: 10)
        phone_side.position = CGPoint(x: 525, y: 224)
        addChild(phone_side)
            
            // Ending Page
            logo.size = CGSize(width: 161.5, height: 109)
            logo.position = CGPoint(x: 512, y: 450)
            logo.zPosition = 1001
            logo.isHidden = true
            logo.alpha = 0
            addChild(logo)
            
            EndingTitle1.text = "\(EndingData[0])"
            EndingTitle1.fontSize = 48
            EndingTitle1.fontColor = #colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)
            EndingTitle1.position = CGPoint(x: 512, y: 350)
            EndingTitle1.zPosition = 1002
            EndingTitle1.isHidden = true
            EndingTitle1.alpha = 0
            addChild(EndingTitle1)
            
            EndingTitle2.text = "Addiction level is " + String(Int(addiction)) + "/100" 
            EndingTitle2.fontSize = 40
            EndingTitle2.fontColor = #colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)
            EndingTitle2.position = CGPoint(x: 512, y: 290)
            EndingTitle2.zPosition = 1003
            EndingTitle2.isHidden = true
            EndingTitle2.alpha = 0
            addChild(EndingTitle2)
            
            EndingTitle3.text = """
\(EndingData[1])
"""
            EndingTitle3.lineBreakMode = NSLineBreakMode.byWordWrapping
            EndingTitle3.preferredMaxLayoutWidth = 700
            EndingTitle3.numberOfLines = 2
            EndingTitle3.fontSize = 40
            EndingTitle3.fontColor = #colorLiteral(red: 0.9999960065, green: 1.0, blue: 1.0, alpha: 1.0)
            EndingTitle3.position = CGPoint(x: 512, y: 130)
            EndingTitle3.zPosition = 1004
            EndingTitle3.isHidden = true
            EndingTitle3.alpha = 0
            addChild(EndingTitle3)
            
        // bubble 0
        bubble_0.size = CGSize(width: 200, height: 100)
        bubble_0.position = CGPoint(x: 525, y: 300)
        addChild(bubble_0)
        
        bubble_0_title.text = """
\(GameData[0])
"""
        bubble_0_title.lineBreakMode = NSLineBreakMode.byWordWrapping
        bubble_0_title.preferredMaxLayoutWidth = 200
        bubble_0_title.numberOfLines = 23
        bubble_0_title.fontSize = 20
        bubble_0_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        bubble_0_title.position = CGPoint(x: bubble_0.position.x, y: bubble_0.position.y - 15)
        addChild(bubble_0_title)
        
        // bubble1
        
        bubble_1.size = CGSize(width: 200, height: 100)
        bubble_1.position = CGPoint(x: 875, y: 450)
        addChild(bubble_1)
        
        bubble_1_title.text = """
\(GameData[1])
"""
        bubble_1_title.lineBreakMode = NSLineBreakMode.byWordWrapping
        bubble_1_title.preferredMaxLayoutWidth = 180
        bubble_1_title.numberOfLines = 23
        bubble_1_title.fontSize = 20
        bubble_1_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        bubble_1_title.position = CGPoint(x: bubble_1.position.x - 10, y: bubble_1.position.y - 25)
        addChild(bubble_1_title)
        
        // bubble 2
        bubble_2.size = CGSize(width: 200, height: 100)
        bubble_2.position = CGPoint(x: 820, y: 435)
        addChild(bubble_2)
        bubble_2.isHidden = true
        bubble_2_title.isHidden = true
        bubble_2_title.text = """
\(GameData[2])
"""
        bubble_2_title.lineBreakMode = NSLineBreakMode.byWordWrapping
        bubble_2_title.preferredMaxLayoutWidth = 200
        bubble_2_title.numberOfLines = 23
        bubble_2_title.fontSize = 20
        bubble_2_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        bubble_2_title.position = CGPoint(x: bubble_2.position.x, y: bubble_2.position.y - 5)
        addChild(bubble_2_title)
        
        // bubble 0 stage 1
        bubble_0_1.size = CGSize(width: 200, height: 100)
        bubble_0_1.position = CGPoint(x: 400, y: 400)
        addChild(bubble_0_1)
        bubble_0_1.isHidden = true
        bubble_0_1_title.isHidden = true
        bubble_0_1_title.text = """
\(GameData[3])
"""
        bubble_0_1_title.lineBreakMode = NSLineBreakMode.byWordWrapping
        bubble_0_1_title.preferredMaxLayoutWidth = 200
        bubble_0_1_title.numberOfLines = 23
        bubble_0_1_title.fontSize = 20
        bubble_0_1_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        bubble_0_1_title.position = CGPoint(x: bubble_0_1.position.x, y: bubble_0_1.position.y - 5)
        addChild(bubble_0_1_title)
            
            // phone button 0
            phone_button0.size = CGSize(width: 320, height: 46)
            phone_button0.position = CGPoint(x: 803, y: 205)
            addChild(phone_button0)
            phone_button0.isHidden = true
            phone_button0_title.isHidden = true
            phone_button0_title.text = """
\(GameData[4])
"""
            phone_button0_title.lineBreakMode = NSLineBreakMode.byWordWrapping
            phone_button0_title.preferredMaxLayoutWidth = 200
            phone_button0_title.numberOfLines = 23
            phone_button0_title.fontSize = 20
            phone_button0_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
            phone_button0_title.position = CGPoint(x: phone_button0.position.x, y: phone_button0.position.y - 13)
            addChild(phone_button0_title)
            phone_button0.zPosition = 502
            phone_button0_title.zPosition = 503
            
            // phone button 1
            phone_button1.size = CGSize(width: 320, height: 46)
            phone_button1.position = CGPoint(x: 803, y: 152)
            addChild(phone_button1)
            phone_button1.isHidden = true
            phone_button1_title.isHidden = true
            phone_button1_title.text = """
\(GameData[5])
"""
            phone_button1_title.lineBreakMode = NSLineBreakMode.byWordWrapping
            phone_button1_title.preferredMaxLayoutWidth = 200
            phone_button1_title.numberOfLines = 23
            phone_button1_title.fontSize = 20
            phone_button1_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
            phone_button1_title.position = CGPoint(x: phone_button1.position.x, y: phone_button1.position.y - 13)
            addChild(phone_button1_title)
            phone_button1.zPosition = 504
            phone_button1_title.zPosition = 505
            
            // bubble 1 scene 1
            bubble_1_1.size = CGSize(width: 200, height: 100)
            bubble_1_1.position = CGPoint(x: 875, y: 450)
            addChild(bubble_1_1)
            bubble_1_1.isHidden = true
            bubble_1_1_title.isHidden = true
            bubble_1_1_title.text = """
\(GameData[6])
"""
            bubble_1_1_title.lineBreakMode = NSLineBreakMode.byWordWrapping
            bubble_1_1_title.preferredMaxLayoutWidth = 150
            bubble_1_1_title.numberOfLines = 23
            bubble_1_1_title.fontSize = 20
            bubble_1_1_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
            bubble_1_1_title.position = CGPoint(x: bubble_1_1.position.x - 10, y: bubble_1_1.position.y - 25)
            addChild(bubble_1_1_title)
            
            // bubble 0 scene 2
            bubble_0_2.size = CGSize(width: 200, height: 100)
            bubble_0_2.position = CGPoint(x: 483, y: 355)
            addChild(bubble_0_2)
            bubble_0_2.isHidden = true
            bubble_0_2_title.isHidden = true
            bubble_0_2.zPosition = 600
            bubble_0_2_title.zPosition = 601
            bubble_0_2_title.text = """
\(GameData[7])
"""
            bubble_0_2_title.lineBreakMode = NSLineBreakMode.byWordWrapping
            bubble_0_2_title.preferredMaxLayoutWidth = 200
            bubble_0_2_title.numberOfLines = 23
            bubble_0_2_title.fontSize = 16
            bubble_0_2_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
            bubble_0_2_title.position = CGPoint(x: bubble_0_2.position.x, y: bubble_0_2.position.y - 12)
            addChild(bubble_0_2_title)
            
            // bubble 1 scene 2
            bubble_1_2.size = CGSize(width: 200, height: 100)
            bubble_1_2.position = CGPoint(x: 140, y: 456)
            addChild(bubble_1_2)
            bubble_1_2.isHidden = true
            bubble_1_2_title.isHidden = true
            bubble_1_2_title.text = """
\(GameData[8])
"""
            bubble_1_2_title.lineBreakMode = NSLineBreakMode.byWordWrapping
            bubble_1_2_title.preferredMaxLayoutWidth = 200
            bubble_1_2_title.numberOfLines = 23
            bubble_1_2_title.fontSize = 16
            bubble_1_2_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
            bubble_1_2_title.position = CGPoint(x: bubble_1_2.position.x + 5, y: bubble_1_2.position.y - 20)
            addChild(bubble_1_2_title)
            
            // bubble 0 scene 3
            bubble_0_3.size = CGSize(width: 200, height: 100)
            bubble_0_3.position = CGPoint(x: 140, y: 456)
            addChild(bubble_0_3)
            bubble_0_3.isHidden = true
            bubble_0_3_title.isHidden = true
            bubble_0_3_title.text = """
\(GameData[9])
"""
            bubble_0_3_title.lineBreakMode = NSLineBreakMode.byWordWrapping
            bubble_0_3_title.preferredMaxLayoutWidth = 170
            bubble_0_3_title.numberOfLines = 23
            bubble_0_3_title.fontSize = 20
            bubble_0_3_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
            bubble_0_3_title.position = CGPoint(x: bubble_0_3.position.x + 5, y: bubble_0_3.position.y - 25)
            addChild(bubble_0_3_title)
            
            // phone button 0 scene 3
            phone_button0_3.size = CGSize(width: 320, height: 46)
            phone_button0_3.position = CGPoint(x: 803, y: 205)
            addChild(phone_button0_3)
            phone_button0_3.isHidden = true
            phone_button0_3_title.isHidden = true
            phone_button0_3_title.text = """
\(GameData[10])
"""
            phone_button0_3_title.lineBreakMode = NSLineBreakMode.byWordWrapping
            phone_button0_3_title.preferredMaxLayoutWidth = 200
            phone_button0_3_title.numberOfLines = 23
            phone_button0_3_title.fontSize = 20
            phone_button0_3_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
            phone_button0_3_title.position = CGPoint(x: phone_button0_3.position.x, y: phone_button0_3.position.y - 13)
            addChild(phone_button0_3_title)
            phone_button0_3.zPosition = 502
            phone_button0_3_title.zPosition = 503
            
            // phone button 1 scene 3
            phone_button1_3.size = CGSize(width: 320, height: 46)
            phone_button1_3.position = CGPoint(x: 803, y: 152)
            addChild(phone_button1_3)
            phone_button1_3.isHidden = true
            phone_button1_3_title.isHidden = true
            phone_button1_3_title.text = """
\(GameData[11])
"""
            phone_button1_3_title.lineBreakMode = NSLineBreakMode.byWordWrapping
            phone_button1_3_title.preferredMaxLayoutWidth = 320
            phone_button1_3_title.numberOfLines = 23
            phone_button1_3_title.fontSize = 16
            phone_button1_3_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
            phone_button1_3_title.position = CGPoint(x: phone_button1_3.position.x, y: phone_button1_3.position.y - 13)
            addChild(phone_button1_3_title)
            phone_button1_3.zPosition = 504
            phone_button1_3_title.zPosition = 505
            
            // bubble 0 scene 5
            bubble_0_5.size = CGSize(width: 200, height: 100)
            bubble_0_5.position = CGPoint(x: 140, y: 456)
            addChild(bubble_0_5)
            bubble_0_5.isHidden = true
            bubble_0_5_title.isHidden = true
            bubble_0_5_title.text = """
\(GameData[12])
"""
            bubble_0_5_title.lineBreakMode = NSLineBreakMode.byWordWrapping
            bubble_0_5_title.preferredMaxLayoutWidth = 170
            bubble_0_5_title.numberOfLines = 23
            bubble_0_5_title.fontSize = 20
            bubble_0_5_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
            bubble_0_5_title.position = CGPoint(x: bubble_0_5.position.x + 5, y: bubble_0_5.position.y - 12)
            addChild(bubble_0_5_title)
            
            // bubble 1 stage 5
            bubble_1_5.size = CGSize(width: 200, height: 100)
            bubble_1_5.position = CGPoint(x: 273, y: 336)
            addChild(bubble_1_5)
            bubble_1_5.isHidden = true
            bubble_1_5_title.isHidden = true
            bubble_1_5_title.text = """
\(GameData[14])
"""
            bubble_1_5_title.lineBreakMode = NSLineBreakMode.byWordWrapping
            bubble_1_5_title.preferredMaxLayoutWidth = 200
            bubble_1_5_title.numberOfLines = 23
            bubble_1_5_title.fontSize = 20
            bubble_1_5_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
            bubble_1_5_title.position = CGPoint(x: bubble_1_5.position.x, y: bubble_1_5.position.y - 5)
            addChild(bubble_1_5_title)
            
            // bubble 0 stage 6
            bubble_0_6.size = CGSize(width: 200, height: 100)
            bubble_0_6.position = CGPoint(x: 225, y: 300)
            addChild(bubble_0_6)
            bubble_0_6.isHidden = true
            bubble_0_6_title.isHidden = true
            bubble_0_6_title.text = """
\(GameData[16])
"""
            bubble_0_6_title.lineBreakMode = NSLineBreakMode.byWordWrapping
            bubble_0_6_title.preferredMaxLayoutWidth = 200
            bubble_0_6_title.numberOfLines = 23
            bubble_0_6_title.fontSize = 20
            bubble_0_6_title.fontColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
            bubble_0_6_title.position = CGPoint(x: bubble_0_6.position.x, y: bubble_0_6.position.y - 5)
            addChild(bubble_0_6_title)
        }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let location = touches.first?.location(in: self) {
            tapEnded(node: self.atPoint(location))
            
                // Walking
            var char_speed = abs((location.x - player.position.x) / 500)
            let movement = SKAction.moveTo(x: location.x, duration: TimeInterval(char_speed))
            if stage_number == 2 && location.x > 530 {
                
            }else{
                if location.x > player.position.x {
                    let right = SKTexture(imageNamed: char_clothes + "right.png")
                    player.texture = right
                    player.run(movement)
                } else {
                    let left = SKTexture(imageNamed: char_clothes + "left.png")
                    player.texture = left
                    player.run(movement)
                }
            }
            

        }
    }
    
    func tapEnded(node : SKNode) { 
        // bubble 0
        if node == bubble_0 || node == bubble_0_title {
            ButtonActions().bubble_0_action()
        }
        // bubble 1
        if node == bubble_1 || node == bubble_1_title {
            ButtonActions().bubble_1_action()
        }
        
        // bubble 2
        if node == bubble_2 || node == bubble_2_title {
            StageSwitches().changeStageHomeToWork()
        }
        
        // bubble 0 stage 1
        if node == bubble_0_1 || node == bubble_0_1_title {
            ButtonActions().bubble_0_1_action()
        }
        
        // phone button 0
        if node == phone_button0 || node == phone_button0_title {
            ButtonActions().phone_button0_action()
        }
        
        // phone button 1
        if node == phone_button1 || node == phone_button1_title {
            ButtonActions().phone_button1_action()
        }
        
        // bubble 1 scene 1
        if node == bubble_1_1 || node == bubble_1_1_title {
            StageSwitches().changeStageWorkToBalcony()
        }
        
        // bubble 0 scene 2
        if node == bubble_0_2 || node == bubble_0_2_title {
            ButtonActions().bubble_0_2_action()
        }
        
        // bubble 1 scene 2
        if node == bubble_1_2 || node == bubble_1_2_title {
            StageSwitches().changeStageBalconyToWork()
        }
        
        // bubble 0 scene 3
        if node == bubble_0_3 || node == bubble_0_3_title {
            StageSwitches().changeStageWorkToOutside()
        }
        
        // phone button 0 stage 3
        if node == phone_button0_3 || node == phone_button0_3_title {
            StageSwitches().changeStageOutsideToNight()
        }
        
        // phone button 1 stage 3
        if node == phone_button1_3 || node == phone_button1_3_title {
            StageSwitches().changeStageToHome()
        }
        
        // phone button 0 stage 5
        if node == bubble_0_5 || node == bubble_0_5_title {
            StageSwitches().changeStageToHome()
        }
        
        // phone button 1 stage 5
        if node == bubble_1_5 || node == bubble_1_5_title {
            ButtonActions().bubble_1_5_action()
        }
        
        // bubble 0 scene 6
        if node == bubble_0_6 || node == bubble_0_6_title {
            StageSwitches().gameEnding()
        }
    }
}
