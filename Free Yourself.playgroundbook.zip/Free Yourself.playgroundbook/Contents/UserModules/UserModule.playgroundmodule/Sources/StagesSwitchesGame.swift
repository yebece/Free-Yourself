import SpriteKit

public class StageSwitches : SKScene {
    public func changeStageHomeToWork(){
        stage_number = 1
        print(stage_number)
        bubble_2.alpha = 1
        // This action fades the screen and changes the scene
        var fades = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
        blackOut.run(fades)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { 
            bubble_1.isHidden = true
            bubble_1_title.isHidden = true
            bubble_2.isHidden = true
            bubble_2_title.isHidden = true
            bubble_0_1.isHidden = false
            bubble_0_1_title.isHidden = false
            player.position = CGPoint(x: 700, y: 205)
            let left = SKTexture(imageNamed: char_clothes + "left.png")
            player.texture = left
            let stageSwitch = SKTexture(imageNamed: "stage_office.png")
            background.texture = stageSwitch
            // This action shows the scene again
            var deFade = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
            chair.isHidden = false
            blackOut.run(deFade)
        }                
    }
    
    public func changeStageWorkToBalcony(){
        // This action fades the screen and changes the scene
        var fades = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
        blackOut.run(fades)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { 
            bubble_1_1.isHidden = true
            bubble_1_1_title.isHidden = true
            balconyGuy.isHidden = false
            player.position = CGPoint(x: 150, y: 205)
            let right = SKTexture(imageNamed: char_clothes + "right.png")
            player.texture = right
            let stageSwitch = SKTexture(imageNamed: "balcony.png")
            background.texture = stageSwitch
            chair.isHidden = true
            bubble_0_2.isHidden = false
            bubble_0_2_title.isHidden = false
            bubble_1_2.isHidden = false
            bubble_1_2_title.isHidden = false
            stage_number = 2
            print(stage_number)
            // This action shows the scene again
            var deFade = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
            blackOut.run(deFade)
        }                
    }
    
    
    
    public func changeStageBalconyToWork(){
        // This action fades the screen and changes the scene
        var fades = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
        blackOut.run(fades)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { 
            player.position = CGPoint(x: 700, y: 205)
            let left = SKTexture(imageNamed: char_clothes + "left.png")
            player.texture = left
            let stageSwitch = SKTexture(imageNamed: "stage_office.png")
            background.texture = stageSwitch
            bubble_1_2.isHidden = true
            bubble_1_2_title.isHidden = true
            bubble_0_2.isHidden = true
            balconyGuy.isHidden = true
            bubble_0_2_title.isHidden = true
            chair.isHidden = false
            bubble_0_3.isHidden = false
            bubble_0_3_title.isHidden = false 
            stage_number = 3
            print(stage_number)
            // This action shows the scene again
            var deFade = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
            blackOut.run(deFade)
        }                
    }
    
    public func changeStageWorkToOutside(){
        // This action fades the screen and changes the scene
        var fades = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
        blackOut.run(fades)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { 
            player.position = CGPoint(x: 700, y: 205)
            let left = SKTexture(imageNamed: char_clothes + "left.png")
            player.texture = left
            let stageSwitch = SKTexture(imageNamed: "outside.png")
            background.texture = stageSwitch
            bubble_0_3.isHidden = true
            bubble_0_3_title.isHidden = true
            chair.isHidden = true
            stage_number = 4
            print(stage_number)
            // This action shows scene again
            var deFade = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
            blackOut.run(deFade)
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                phoneInv.isHidden = false
                phone_button0_3.isHidden = false
                phone_button0_3_title.isHidden = false
                phone_button1_3.isHidden = false
                phone_button1_3_title.isHidden = false
                let notificationSound = SKAction.playSoundFileNamed("notification.mp3", waitForCompletion: false)
                phone.run(notificationSound)
            }
        }                
    }
    
    public func changeStageOutsideToNight(){
        // This action fades the screen and changes the scene
        var fades = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
        blackOut.run(fades)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { 
            player.position = CGPoint(x: 150, y: 205)
            let left = SKTexture(imageNamed: char_clothes + "right.png")
            player.texture = left
            let stageSwitch = SKTexture(imageNamed: "night.png")
            phoneInv.isHidden = true
            phone_button0_3.isHidden = true
            phone_button0_3_title.isHidden = true
            bubble_0_5.isHidden = false
            bubble_0_5_title.isHidden = false
            bubble_1_5.isHidden = false
            bubble_1_5_title.isHidden = false
            phone_button1_3.isHidden = true
            phone_button1_3_title.isHidden = true
            background.texture = stageSwitch
            stage_number = 5
            print(stage_number)
            // This action shows the scene again
            var deFade = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
            blackOut.run(deFade)
        }                
    }
    
    public func changeStageToHome(){
        // This action fades the screen and changes the scene
        var fades = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
        blackOut.run(fades)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { 
            player.position = CGPoint(x: 822, y: 205)
            char_clothes = "char_"
            phoneInv.isHidden = true
            phone_button0_3.isHidden = true
            phone_button0_3_title.isHidden = true
            phone_button1_3.isHidden = true
            phone_button1_3_title.isHidden = true
            phone_side.isHidden = false
            bubble_0.isHidden = false
            bubble_0_title.isHidden = false
            bubble_0_5.isHidden = true
            bubble_0_5_title.isHidden = true
            bubble_1_5.isHidden = true
            bubble_1_5_title.isHidden = true
            bubble_0_6.isHidden = false
            bubble_0_6_title.isHidden = false
            let left = SKTexture(imageNamed: char_clothes + "left.png")
            player.texture = left
            let stageSwitch = SKTexture(imageNamed: "home_night.png")
            background.texture = stageSwitch
            stage_number = 6
            print(stage_number)
            // This action shows the scene again
            var deFade = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
            blackOut.run(deFade)
        }                
    }
    
    public func gameEnding(){
        let stageSwitch = SKTexture(imageNamed: "home_night_lights_off.png")
        background.texture = stageSwitch
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            var fades = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
            blackOut.run(fades)
            GeneralFuncs().endingPage()
        }                
        
    }
    
}
